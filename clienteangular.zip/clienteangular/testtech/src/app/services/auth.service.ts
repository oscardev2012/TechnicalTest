import { Injectable } from '@angular/core';
import axios from 'axios';

@Injectable({ providedIn: 'root' })
export class AuthService {

  private api = 'http://localhost:5079/api';

  async loginFake(): Promise<void> {
    const res = await axios.get(`${this.api}/auth/fake-token`);
    localStorage.setItem('token', res.data.token);
  }

  getToken() {
    return localStorage.getItem('token');
  }

  logout() {
    localStorage.removeItem('token');
  }
}
