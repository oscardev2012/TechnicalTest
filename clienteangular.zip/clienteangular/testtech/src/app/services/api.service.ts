import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ApiService {

  private url = 'http://localhost:5079/api'; // AJUSTA PUERTO

  constructor(private http: HttpClient) { }

  // Productos
  async getProducts() {
    const res = await firstValueFrom(
      this.http.get<{ items: any[] }>(`${this.url}/products`)
    );
    return res.items;
  }

  async getProduct(id: number) {
    return await firstValueFrom(
      this.http.get<any>(`${this.url}/products/${id}`)
    );
  }

  async createProduct(payload: any) {
    return await firstValueFrom(
      this.http.post(`${this.url}/products`, payload)
    );
  }

  async updateProduct(id: number, payload: any) {
    return await firstValueFrom(
      this.http.put(`${this.url}/products/${id}`, payload)
    );
  }

  async deleteProduct(id: number) {
    return await firstValueFrom(
      this.http.delete(`${this.url}/products/${id}`)
    );
  }

  // Ventas
  async createSale(payload: any) {
    return await firstValueFrom(
      this.http.post(`${this.url}/sales`, payload)
    );
  }

  async getSales() {
    return await firstValueFrom(
      this.http.get<any>(`${this.url}/sales/report`)
    );
  }

  async getReport(from: string, to: string, page: number = 1, pageSize: number = 10) {
    const url =
      `${this.url}/sales/report?from=${from}&to=${to}` +
      `&page=${page}&pageSize=${pageSize}`;

    return await firstValueFrom(
      this.http.get<{
        items: any[],
        page: number,
        pageSize: number,
        totalCount: number
      }>(url)
    );
  }

}
