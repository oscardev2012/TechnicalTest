import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';

@Component({
  standalone: true,
  selector: 'app-sales',
  imports: [CommonModule, FormsModule],
  templateUrl: './sales.html'
})
export class SalesComponent implements OnInit {

  products: any[] = [];
  productId = 0;
  quantity = 1;

  constructor(private api: ApiService) {}

  async ngOnInit() {
    this.products = await this.api.getProducts();
  }

  async create() {
    const payload = {
      items: [
        {
          productId: this.productId,
          quantity: this.quantity,
          unitPrice: 0
        }
      ]
    };

    await this.api.createSale(payload);
    alert("Venta registrada correctamente");
  }
}
