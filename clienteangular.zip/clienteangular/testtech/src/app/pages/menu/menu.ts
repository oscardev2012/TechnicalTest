import { Component } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';

@Component({
  standalone: true,
  selector: 'app-menu',
  imports: [RouterOutlet, RouterLink],
  templateUrl: './menu.html'
})
export class DashboardComponent {}
