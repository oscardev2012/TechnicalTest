import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

@Component({
  standalone: true,
  selector: 'app-login',
  templateUrl: './login.html'
})
export class LoginComponent {

  private api = 'http://localhost:5079/api'; // ajusta puerto

  constructor(private router: Router, private http: HttpClient) {}

  async login() {
    const obs$ = this.http.get<any>(`${this.api}/auth/fake-token`);
    const res = await firstValueFrom(obs$);

    localStorage.setItem('token', res.token);

    this.router.navigate(['/dashboard']);
  }
}
