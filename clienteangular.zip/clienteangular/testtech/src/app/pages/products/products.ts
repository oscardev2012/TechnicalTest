import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';

@Component({
  standalone: true,
  selector: 'app-products',
  imports: [CommonModule, FormsModule],
  templateUrl: './products.html'
})
export class ProductsComponent implements OnInit {

  products: any[] = [];

  // Campos del formulario
  id: number | null = null;
  name: string = '';
  price: number = 0;
  stock: number = 0;

  constructor(private api: ApiService) {}

  async ngOnInit() {
    await this.loadProducts();
  }

  async loadProducts() {
    this.products = await this.api.getProducts();
  }

  // Crear o actualizar
  async save() {
    const payload = {
      name: this.name,
      price: this.price,
      stock: this.stock
    };

    if (this.id === null) {
      await this.api.createProduct(payload);
    } else {
      await this.api.updateProduct(this.id, payload);
    }

    this.clearForm();
    await this.loadProducts();
  }

  async edit(p: any) {
    this.id = p.id;
    this.name = p.name;
    this.price = p.price;
    this.stock = p.stock;
  }

  async remove(id: number) {
    if (!confirm("¿Eliminar producto?")) return;
    await this.api.deleteProduct(id);
    await this.loadProducts();
  }

  clearForm() {
    this.id = null;
    this.name = '';
    this.price = 0;
    this.stock = 0;
  }
}
