import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';

@Component({
  standalone: true,
  selector: 'app-sales-report',
  imports: [CommonModule, FormsModule],
  templateUrl: './sales-report.html'
})
export class SalesReportComponent {

  from!: string;
  to!: string;

  page = 1;
  pageSize = 10;

  items: any[] = [];
  totalCount = 0;

  constructor(private api: ApiService) { }

  async search() {
    if (!this.from || !this.to) {
      alert("Debe seleccionar las fechas");
      return;
    }

    const result = await this.api.getReport(this.from, this.to, this.page, this.pageSize);

    this.items = result.items;
    this.totalCount = result.totalCount;
    this.page = result.page;
    this.pageSize = result.pageSize;
  }

  get totalPages() {
    return Math.ceil(this.totalCount / this.pageSize);
  }

  async next() {
    if (this.page * this.pageSize >= this.totalCount) return;
    this.page++;
    await this.search();
  }

  async prev() {
    if (this.page <= 1) return;
    this.page--;
    await this.search();
  }
}
