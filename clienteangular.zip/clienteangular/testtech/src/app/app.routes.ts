import { Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login';
import { DashboardComponent } from './pages/menu/menu';
import { ProductsComponent } from './pages/products/products';
import { SalesComponent } from './pages/sales/sales';
import { SalesReportComponent } from './pages/sales-report/sales-report';

export const routes: Routes = [
  { path: '', component: LoginComponent },
  {
    path: 'dashboard',
    component: DashboardComponent,
    children: [
      { path: 'products', component: ProductsComponent },
      { path: 'sales', component: SalesComponent },
      { path: 'report', component: SalesReportComponent }
    ]
  }
];
